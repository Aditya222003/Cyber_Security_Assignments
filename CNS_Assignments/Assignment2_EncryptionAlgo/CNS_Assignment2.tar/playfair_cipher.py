import re

def create_playfair_matrix(key):
    key = key.upper().replace("J", "I")
    matrix = []
    used_chars = set()
    for char in key:
        if char not in used_chars and char.isalpha():
            used_chars.add(char)
            matrix.append(char)
    for char in "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if char not in used_chars:
            used_chars.add(char)
            matrix.append(char)
    return [matrix[i:i + 5] for i in range(0, 25, 5)]

def preprocess_text(text, add_padding=True):
    text = text.upper().replace("J", "I")
    text = re.sub(r'[^A-Z]', '', text)
    text = re.sub(r'(.)\1+', r'\1X', text)  # Replace duplicate letters with letter+X
    if add_padding and len(text) % 2 != 0:
        text += 'X'
    return text

def find_position(matrix, char):
    for i, row in enumerate(matrix):
        if char in row:
            return i, row.index(char)
    return None

def playfair_encrypt(plaintext, key):
    matrix = create_playfair_matrix(key)
    plaintext_cleaned = preprocess_text(plaintext)
    ciphertext = ""
    for i in range(0, len(plaintext_cleaned), 2):
        a, b = plaintext_cleaned[i], plaintext_cleaned[i+1]
        row1, col1 = find_position(matrix, a)
        row2, col2 = find_position(matrix, b)
        if row1 == row2:
            ciphertext += matrix[row1][(col1 + 1) % 5]
            ciphertext += matrix[row2][(col2 + 1) % 5]
        elif col1 == col2:
            ciphertext += matrix[(row1 + 1) % 5][col1]
            ciphertext += matrix[(row2 + 1) % 5][col2]
        else:
            ciphertext += matrix[row1][col2]
            ciphertext += matrix[row2][col1]
    return ciphertext

def playfair_decrypt(ciphertext, key):
    matrix = create_playfair_matrix(key)
    plaintext = ""
    for i in range(0, len(ciphertext), 2):
        a, b = ciphertext[i], ciphertext[i+1]
        row1, col1 = find_position(matrix, a)
        row2, col2 = find_position(matrix, b)
        if row1 == row2:
            plaintext += matrix[row1][(col1 - 1) % 5]
            plaintext += matrix[row2][(col2 - 1) % 5]
        elif col1 == col2:
            plaintext += matrix[(row1 - 1) % 5][col1]
            plaintext += matrix[(row2 - 1) % 5][col2]
        else:
            plaintext += matrix[row1][col2]
            plaintext += matrix[row2][col1]

    # Remove padding characters and ensure trailing spaces
    plaintext = plaintext.rstrip('X')
    return plaintext

def restore_spaces(original_text, decrypted_text):
    decrypted_text_list = list(decrypted_text)
    original_text_cleaned = re.sub(r'[^A-Z]', '', original_text).upper()
    index = 0
    result = []
    for char in original_text:
        if char == ' ':
            result.append(' ')
        elif index < len(decrypted_text_list):
            result.append(decrypted_text_list[index])
            index += 1
    return ''.join(result)

# Example usage
plaintext = "Hide the gold in the tree stump"
key = "KEYWORD"
formatted_plaintext = preprocess_text(plaintext, add_padding=False)  # No padding in plaintext
encrypted_text = playfair_encrypt(formatted_plaintext, key)
decrypted_text = playfair_decrypt(encrypted_text, key)
restored_text = restore_spaces(plaintext, decrypted_text)

print(f"Original: {plaintext}")
print(f"Encrypted: {encrypted_text}")
print(f"Decrypted: {restored_text}")
