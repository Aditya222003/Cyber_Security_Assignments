def rail_fence_encrypt(plaintext, num_rails):
    if num_rails == 1:
        return plaintext

    # Create a matrix of rails
    rails = [['' for _ in range(len(plaintext))] for _ in range(num_rails)]
    rail = 0
    direction = 1  # 1 means moving down, -1 means moving up

    # Fill the rail matrix
    for char in plaintext:
        rails[rail].append(char)
        rail += direction
        if rail == 0 or rail == num_rails - 1:
            direction *= -1

    # Read the rail matrix row by row
    encrypted_text = ''.join([''.join(row) for row in rails])
    return encrypted_text

def rail_fence_decrypt(ciphertext, num_rails):
    if num_rails == 1:
        return ciphertext

    # Create a matrix to hold the characters
    rails = [['' for _ in range(len(ciphertext))] for _ in range(num_rails)]
    rail = 0
    direction = 1  # 1 means moving down, -1 means moving up

    # Mark the positions with '*' where the ciphertext will go
    for i in range(len(ciphertext)):
        rails[rail][i] = '*'
        rail += direction
        if rail == 0 or rail == num_rails - 1:
            direction *= -1

    # Fill the matrix with ciphertext characters
    index = 0
    for r in range(num_rails):
        for c in range(len(ciphertext)):
            if rails[r][c] == '*':
                rails[r][c] = ciphertext[index]
                index += 1

    # Read the matrix in the zigzag pattern to get the decrypted text
    decrypted_text = []
    rail = 0
    direction = 1
    for i in range(len(ciphertext)):
        decrypted_text.append(rails[rail][i])
        rail += direction
        if rail == 0 or rail == num_rails - 1:
            direction *= -1

    return ''.join(decrypted_text)

# Example usage
plaintext = "Hide the gold in the tree stump"
num_rails = 3
encrypted_text = rail_fence_encrypt(plaintext, num_rails)
decrypted_text = rail_fence_decrypt(encrypted_text, num_rails)

print(f"Original: {plaintext}")
print(f"Encrypted: {encrypted_text}")
print(f"Decrypted: {decrypted_text}")
